//
//  BuyBuddyKit iOS.h
//  BuyBuddyKit iOS
//
//  Created by Buğra Ekuklu on 25.02.2017.
//
//

#import <Foundation/Foundation.h>

//! Project version number for BuyBuddyKit iOS.
FOUNDATION_EXPORT double BuyBuddyKitVersionNumber;

//! Project version string for BuyBuddyKit iOS.
FOUNDATION_EXPORT const unsigned char BuyBuddyKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BuyBuddyKit/PublicHeader.h>


